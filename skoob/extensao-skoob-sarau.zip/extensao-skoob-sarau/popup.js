const $ = (id) => document.getElementById(id);
let abaSkoob = null;
let ultimo = {};


function aviso(texto) {
  $('aviso').hidden = !texto;
  $('aviso').textContent = texto || '';
}

const escapar = (t) => String(t ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

async function abaAtual() {
  const [aba] = await chrome.tabs.query({ active: true, currentWindow: true });
  return aba && /^https:\/\/(www\.)?skoob\.com\.br\//.test(aba.url || '') ? aba : null;
}

async function iniciar(opcoes) {
  if (!abaSkoob) return;
  try {
    await chrome.scripting.executeScript({ target: { tabId: abaSkoob.id }, files: ['coletor.js'] });
    await chrome.tabs.sendMessage(abaSkoob.id, { tipo: 'coletar', opcoes });
  } catch (e) {
    aviso('Não consegui falar com a aba do Skoob. Aperte F5 nela e tente de novo.');
  }
}

const NOMES_FILTRO = { favorited: 'Favorito', owned: 'Tenho', desired: 'Desejado' };

/** Estante de leitura do livro, pelos filtros do Skoob (ou pelo status, nas coletas antigas). */
function estanteDe(l) {
  const f = l.filtros || [l.status];
  if (f.includes('read')) return 'read';
  if (f.includes('reading') || f.includes('rereading')) return 'currently-reading';
  if (f.includes('want_to_read')) return 'to-read';
  if (f.includes('abandoned')) return 'abandoned';
  if (f.includes('desired')) return 'desired';
  return l.finished_at ? 'read' : null;
}

/** Decide o que vai no arquivo, o que vai sem ISBN e o que fica de fora (e por quê). */
function analisar(s, comResenhas, comDesejados, comTenho) {
  const vistos = new Set();
  const linhas = [];
  const semIsbn = [];
  const fora = [];
  const estantes = { read: 0, 'currently-reading': 0, 'to-read': 0, owned: 0 };
  let resenhas = 0;
  for (const l of s.livros || []) {
    const item = { titulo: l.title, autor: (l.author || '').trim() };
    let estante = estanteDe(l);
    if (estante === 'abandoned') {
      fora.push({ ...item, motivo: 'Abandonado: o Sarau ainda não importa abandonados' });
      continue;
    }
    if (estante === 'desired') {
      if (!comDesejados) {
        fora.push({ ...item, motivo: 'Desejado: marque “Levar os desejados” para incluir' });
        continue;
      }
      estante = 'to-read';
    }
    if (!estante && comTenho && (l.filtros || []).includes('owned')) estante = 'owned';
    if (!estante) {
      const onde = (l.filtros || []).map((f) => NOMES_FILTRO[f]).filter(Boolean);
      fora.push({ ...item, motivo: onde.length ? `Só em ${onde.join(' e ')} no Skoob, sem estante de leitura` : 'Sem estante de leitura no Skoob' });
      continue;
    }
    const chave = l.edition_id || l.book_id;
    if (vistos.has(chave)) continue;
    vistos.add(chave);
    const r = comResenhas ? (s.resenhas || {})[String(l.edition_id)] || (s.resenhas || {})[String(l.book_id)] : null;
    const isbn = (s.isbns || {})[l.book_id] || {};
    if (!isbn.isbn13 && !isbn.isbn10) semIsbn.push(item);
    if (r && r.texto) resenhas++;
    estantes[estante]++;
    linhas.push({ l, estante, r, isbn });
  }
  return { linhas, semIsbn, fora, estantes, resenhas };
}

function lista(el, itens, comMotivo) {
  el.innerHTML = itens
    .map((x) => `<li><i>${escapar(x.titulo)}</i>${x.autor ? ` · ${escapar(x.autor)}` : ''}${comMotivo ? `<small>${escapar(x.motivo)}</small>` : ''}</li>`)
    .join('');
}

function etapa(id, estado) {
  const el = $(id);
  el.classList.toggle('ativa', estado === 'ativa');
  el.classList.toggle('feita', estado === 'feita');
  el.querySelector('.bolinha').textContent = estado === 'feita' ? '✓' : el.dataset.n;
}

function desenhar(s) {
  ultimo = s = s || {};
  const coletando = ['livros', 'resenhas', 'isbn'].includes(s.fase) && Date.now() - (s.atualizadoEm || 0) < 90000;
  const pronto = s.fase === 'pronto' && (s.livros || []).length > 0;

  if (s.fase === 'erro') aviso(s.erro);
  else if (abaSkoob || pronto) aviso('');

  $('telaInicio').hidden = coletando || pronto;
  $('telaColeta').hidden = !coletando;
  $('opcoes').hidden = coletando;
  $('telaPronto').hidden = !pronto || coletando;

  if (coletando) {
    const ordem = ['livros', 'resenhas', 'isbn'];
    const atual = ordem.indexOf(s.fase);
    ['etapaEstante', 'etapaResenhas', 'etapaIsbn'].forEach((id, i) => etapa(id, i < atual ? 'feita' : i === atual ? 'ativa' : ''));
    $('mensagem').textContent = s.mensagem || 'Começando…';
    let pct = 0;
    if (s.fase === 'livros') pct = 35 * ((s.livrosLidos || 0) / Math.max(1, s.totalLivros || 1));
    else if (s.fase === 'resenhas') pct = 42;
    else pct = 50 + 50 * ((s.isbnFeitos || 0) / Math.max(1, s.isbnTotal || 1));
    $('progresso').style.width = Math.min(100, pct) + '%';
  }

  if (pronto) {
    const a = analisar(s, $('comResenhas').checked, $('comDesejados').checked, $('comTenho').checked);
    $('nLivros').textContent = a.linhas.length;
    $('nLidos').textContent = a.estantes.read;
    $('nResenhas').textContent = a.resenhas;
    $('resumoEstantes').textContent = `${a.estantes['currently-reading']} lendo · ${a.estantes['to-read']} quero ler` + (a.estantes.owned ? ` · ${a.estantes.owned} só tenho` : '');
    $('blocoSemIsbn').hidden = !a.semIsbn.length;
    $('nSemIsbn').textContent = a.semIsbn.length;
    lista($('listaSemIsbn'), a.semIsbn, false);
    $('faltantes').hidden = !abaSkoob;
    $('blocoFora').hidden = !a.fora.length;
    $('nFora').textContent = a.fora.length;
    lista($('listaFora'), a.fora, true);
  }

  $('coletar').hidden = coletando;
  $('coletar').disabled = !abaSkoob;
  $('coletar').textContent = pronto ? 'Coletar de novo' : 'Coletar minha estante';
  $('coletar').className = pronto ? 'secundario' : 'primario';
  $('exportar').hidden = !pronto || coletando;
}

function celula(v) {
  const t = v == null ? '' : String(v);
  return /[",\n\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
}

function dataLocal(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return '';
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function montarCsv(s, comResenhas, comDesejados, comTenho) {
  const a = analisar(s, comResenhas, comDesejados, comTenho);
  const cab = ['Title', 'Author', 'ISBN', 'ISBN13', 'My Rating', 'Publisher', 'Number of Pages', 'Year Published', 'Date Read', 'Exclusive Shelf', 'My Review', 'Spoiler'];
  const linhas = [cab.join(',')];
  for (const { l, estante, r, isbn } of a.linhas) {
    const texto = r ? [r.titulo, r.texto].filter((x) => x && x.trim()).join('\n\n') : '';
    linhas.push(
      [
        l.title,
        (l.author || '').trim(),
        isbn.isbn10 || '',
        isbn.isbn13 || '',
        l.rating || (r && r.nota) || '',
        l.publisher || '',
        l.pages || '',
        l.year || '',
        estante === 'read' ? dataLocal(l.finished_at) : '',
        estante,
        texto,
        r && r.spoiler ? 'true' : '',
      ]
        .map(celula)
        .join(','),
    );
  }
  return { csv: '﻿' + linhas.join('\r\n'), n: a.linhas.length };
}

async function exportar() {
  const { sarau } = await chrome.storage.local.get('sarau');
  const { csv, n } = montarCsv(sarau || {}, $('comResenhas').checked, $('comDesejados').checked, $('comTenho').checked);
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = `estante-skoob-para-sarau-${n}-livros.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  $('exportar').textContent = 'Baixado! Agora importe no Sarau 📚';
}

async function salvarOpcoes() {
  await chrome.storage.local.set({ opcoes: { comResenhas: $('comResenhas').checked, comDesejados: $('comDesejados').checked, comTenho: $('comTenho').checked } });
  desenhar(ultimo);
}

$('coletar').addEventListener('click', () => iniciar({}));
$('faltantes').addEventListener('click', () => iniciar({ soIsbn: true }));
$('exportar').addEventListener('click', exportar);
$('comResenhas').addEventListener('change', salvarOpcoes);
$('comDesejados').addEventListener('change', salvarOpcoes);
$('comTenho').addEventListener('change', salvarOpcoes);
chrome.storage.onChanged.addListener((m, area) => {
  if (area === 'local' && m.sarau) desenhar(m.sarau.newValue);
});

(async () => {
  abaSkoob = await abaAtual();
  const { sarau, opcoes } = await chrome.storage.local.get(['sarau', 'opcoes']);
  if (opcoes) {
    $('comResenhas').checked = opcoes.comResenhas !== false;
    $('comDesejados').checked = !!opcoes.comDesejados;
    $('comTenho').checked = !!opcoes.comTenho;
  }
  if (!abaSkoob) aviso('Abra o Skoob (skoob.com.br) nesta janela, na Estante do seu perfil, e clique na extensão de novo.');
  desenhar(sarau);
})();
