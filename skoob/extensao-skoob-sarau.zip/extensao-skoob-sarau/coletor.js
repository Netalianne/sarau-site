// Roda dentro da aba do Skoob (injetado pelo popup). Usa a sessão da própria pessoa,
// lê só a estante dela e guarda tudo no armazenamento da extensão. Nada sai do computador.
(() => {
  if (window.__sarauColetor) return; // já carregado nesta aba
  window.__sarauColetor = true;

  const API = 'https://prd-api.skoob.com.br/api/v1';
  const POR_PAGINA = 50;
  const PARALELO = 4;
  const espera = (ms) => new Promise((r) => setTimeout(r, ms));

  let rodando = false;

  async function salvar(parcial) {
    const { sarau = {} } = await chrome.storage.local.get('sarau');
    const novo = { ...sarau, ...parcial, atualizadoEm: Date.now() };
    await chrome.storage.local.set({ sarau: novo });
    return novo;
  }

  function cookie(nome) {
    const c = document.cookie.split('; ').find((x) => x.startsWith(nome + '='));
    return c ? decodeURIComponent(c.slice(nome.length + 1)) : null;
  }

  function chave() {
    const t = cookie('tokenClient');
    if (!t) return null;
    return /^Bearer /i.test(t) ? t : 'Bearer ' + t;
  }

  /** Id da pessoa: pelo endereço da página (…/user/<id>/…) ou pelo cookie "user". */
  function idDoUsuario() {
    const m = location.pathname.match(/\/user\/([0-9a-f]{24})/i) || location.pathname.match(/\/profile\/([0-9a-f]{24})/i);
    if (m) return m[1];
    const u = cookie('user');
    if (u) {
      try {
        const o = JSON.parse(u);
        const id = o.id || o._id || o.user_id || (o.user && (o.user.id || o.user._id));
        if (id && /^[0-9a-f]{24}$/i.test(id)) return id;
      } catch (e) {
        /* cookie em outro formato */
      }
      const achado = u.match(/[0-9a-f]{24}/i);
      if (achado) return achado[0];
    }
    return null;
  }

  async function api(caminho, tentativas = 3) {
    for (let i = 0; i < tentativas; i++) {
      const r = await fetch(API + caminho, { headers: { Authorization: chave() || '' } });
      if (r.status === 401) throw new Error('SESSAO');
      if (r.ok) return r.json();
      if (r.status === 429 || r.status >= 500) {
        await espera(1500 * (i + 1));
        continue;
      }
      throw new Error('O Skoob respondeu com erro ' + r.status + '.');
    }
    throw new Error('O Skoob não respondeu. Tente de novo em alguns minutos.');
  }

  // O campo "status" do filtro "all" vem como "none" para muitos livros, então a estante de cada
  // livro é descoberta pelos filtros do próprio Skoob (Lido, Lendo, Quero ler…).
  const FILTROS = ['all', 'read', 'reading', 'rereading', 'want_to_read', 'abandoned', 'desired', 'favorited', 'owned'];

  async function coletarLivros(userId) {
    const porChave = new Map();
    let usuario = null;
    for (const [fi, filtro] of FILTROS.entries()) {
      let pagina = 1;
      let total = 1;
      do {
        const d = await api(
          `/bookshelf?page=${pagina}&limit=${POR_PAGINA}&bookshelf_type=book&user_id=${userId}&filter=${filtro}&search_type=title`,
        );
        if (!usuario && d.user) {
          usuario = d.user;
          if (usuario.is_my_profile === false) throw new Error('OUTRO_PERFIL');
        }
        total = d.total_pages || 1;
        for (const it of d.items || []) {
          const chave = String(it.edition_id || it.book_id);
          const atual = porChave.get(chave) || { ...it, filtros: [] };
          if (filtro !== 'all' && !atual.filtros.includes(filtro)) atual.filtros.push(filtro);
          if (!atual.finished_at && it.finished_at) atual.finished_at = it.finished_at;
          if (!atual.rating && it.rating) atual.rating = it.rating;
          porChave.set(chave, atual);
        }
        await salvar({
          fase: 'livros',
          mensagem: `Lendo sua estante (${fi + 1} de ${FILTROS.length}): página ${pagina} de ${total}`,
          livrosLidos: fi * 10 + Math.min(10, (10 * pagina) / Math.max(1, total)),
          totalLivros: FILTROS.length * 10,
        });
        pagina++;
        await espera(200);
      } while (pagina <= total);
    }
    return { livros: [...porChave.values()], usuario };
  }

  async function coletarResenhas(userId) {
    const resenhas = {};
    let pagina = 1;
    for (;;) {
      const d = await api(`/feed/personal?page=${pagina}&limit=20&user_id=${userId}&type=review`);
      const itens = (d.items || []).filter((x) => x.type === 'review' && x.book);
      for (const it of itens) {
        const chaveLivro = String(it.book.edition_id || it.book.book_id);
        if (!resenhas[chaveLivro]) {
          resenhas[chaveLivro] = {
            titulo: it.title || '',
            texto: it.text || '',
            spoiler: !!it.is_spoiler,
            nota: it.rating ?? null,
            book_id: it.book.book_id,
          };
        }
      }
      await salvar({ fase: 'resenhas', mensagem: `Lendo suas resenhas: ${Object.keys(resenhas).length} até agora`, resenhasLidas: Object.keys(resenhas).length });
      if (!(d.items || []).length || (d.items || []).length < 20) break;
      pagina++;
      await espera(250);
    }
    return resenhas;
  }

  /** O ISBN vem dentro da página do livro: "isbn13":"978…" e "isbn10":"…". */
  async function isbnDoLivro(bookId) {
    for (let i = 0; i < 3; i++) {
      const r = await fetch(`/pt/book/${bookId}`, { credentials: 'include' });
      if (r.status === 429 || r.status >= 500) {
        await espera(2000 * (i + 1));
        continue;
      }
      if (!r.ok) return null;
      const h = await r.text();
      const i13 = h.match(/isbn13\\*"\s*:\s*\\*"([0-9Xx]{13})/) || h.match(/ISBN-13:\s*([0-9]{13})/);
      const i10 = h.match(/isbn10\\*"\s*:\s*\\*"([0-9Xx]{10})/) || h.match(/ISBN-10:\s*([0-9Xx]{10})/);
      return { isbn13: i13 ? i13[1] : null, isbn10: i10 ? i10[1].toUpperCase() : null };
    }
    return null;
  }

  async function coletarIsbns(livros, isbnsAntes, soFaltantes) {
    const isbns = { ...(isbnsAntes || {}) };
    const ids = [...new Set(livros.map((l) => l.book_id))].filter((id) =>
      soFaltantes ? !(isbns[id] && (isbns[id].isbn13 || isbns[id].isbn10)) : !(id in isbns),
    );
    let feitos = 0;
    let fila = ids.slice();
    async function trabalhador() {
      while (fila.length) {
        const id = fila.shift();
        try {
          isbns[id] = await isbnDoLivro(id);
        } catch (e) {
          isbns[id] = null;
        }
        feitos++;
        if (feitos % 5 === 0 || !fila.length) {
          const comIsbn = Object.values(isbns).filter((x) => x && (x.isbn13 || x.isbn10)).length;
          await salvar({ fase: 'isbn', mensagem: `Buscando as edições: ${feitos} de ${ids.length}`, isbns, comIsbn, isbnFeitos: feitos, isbnTotal: ids.length });
        }
        await espera(150);
      }
    }
    await Promise.all(Array.from({ length: PARALELO }, trabalhador));
    return isbns;
  }

  async function coletar(opcoes = {}) {
    if (rodando) return;
    rodando = true;
    try {
      if (!chave()) throw new Error('SESSAO');
      const userId = idDoUsuario();
      if (!userId) throw new Error('SEM_ID');
      const { sarau: antes = {} } = await chrome.storage.local.get('sarau');

      if (opcoes.soIsbn && antes.livros && antes.livros.length) {
        await salvar({ fase: 'isbn', erro: null, mensagem: 'Buscando de novo as edições que faltaram…' });
        const isbns = await coletarIsbns(antes.livros, antes.isbns, true);
        const comIsbn = Object.values(isbns).filter((x) => x && (x.isbn13 || x.isbn10)).length;
        await salvar({ fase: 'pronto', mensagem: 'Pronto!', isbns, comIsbn });
        return;
      }

      await salvar({ fase: 'livros', erro: null, mensagem: 'Começando…', livros: [], resenhas: {}, isbns: antes.userId === userId ? antes.isbns || {} : {} });
      const { livros, usuario } = await coletarLivros(userId);
      await salvar({ userId, usuario, livros, totalLivros: livros.length });
      const resenhas = await coletarResenhas(userId);
      await salvar({ resenhas });
      const isbns = await coletarIsbns(livros, antes.userId === userId ? antes.isbns : {}, false);
      const comIsbn = Object.values(isbns).filter((x) => x && (x.isbn13 || x.isbn10)).length;
      await salvar({ fase: 'pronto', mensagem: 'Pronto!', isbns, comIsbn });
    } catch (e) {
      const codigo = e && e.message;
      const msg =
        codigo === 'SESSAO'
          ? 'Não encontramos a sua sessão do Skoob. Entre na sua conta, aperte F5 e tente de novo.'
          : codigo === 'SEM_ID'
            ? 'Abra a aba Estante do seu perfil no Skoob, aperte F5 e tente de novo.'
            : codigo === 'OUTRO_PERFIL'
              ? 'Esta é a estante de outra pessoa. Abra a Estante do seu próprio perfil.'
              : (e && e.message) || 'Algo deu errado.';
      await salvar({ fase: 'erro', erro: msg, mensagem: msg });
    } finally {
      rodando = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg, _remetente, responder) => {
    if (msg && msg.tipo === 'coletar') {
      coletar(msg.opcoes || {});
      responder({ ok: true });
    } else if (msg && msg.tipo === 'situacao') {
      responder({ rodando, temSessao: !!chave(), userId: idDoUsuario() });
    }
    return false;
  });
})();
